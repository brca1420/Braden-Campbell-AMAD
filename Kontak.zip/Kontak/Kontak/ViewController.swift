//
//  ViewController.swift
//  Kontak
//
//  Created by Alex Dugan on 2/16/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

