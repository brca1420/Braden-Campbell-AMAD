//
//  ProfileStringCell.swift
//  Kontak
//
//  Created by Alex Dugan on 2/17/22.
//

import UIKit

class ProfileStringCell: UICollectionViewCell {
    
    @IBOutlet weak var Title: UILabel!
    @IBOutlet weak var Contents: UILabel!
    
    
}
