//
//  SecondViewController.swift
//  AMADLab2
//
//  Created by Alex Dugan on 1/31/22.
//

import UIKit

class SecondViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
    }
    
    @IBOutlet weak var genreStoryLabel: UILabel!
    @IBOutlet weak var datePickerOutlet: UIDatePicker!
    @IBAction func datePickerAction(_ sender: UIDatePicker) {
        genreStoryLabel.text = "You selected the time \(datePickerOutlet.date)"
    }
    

}
