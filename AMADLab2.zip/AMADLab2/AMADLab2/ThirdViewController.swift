//
//  ThirdViewController.swift
//  AMADLab2
//
//  Created by Alex Dugan on 2/1/22.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func theButton(_ sender: UIButton) {
        
        if(UIApplication.shared.canOpenURL(URL(string: "googlegmail://")!)){
            UIApplication.shared.open(URL(string: "googlegmail://")!, options: [:], completionHandler: nil)
        } else {
            let daAlert = UIAlertController(title: "You don't have Gmail?", message: "You gotta get gmail. The mail app sucks.", preferredStyle:  .alert)
            daAlert.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(daAlert, animated: true, completion: nil)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
