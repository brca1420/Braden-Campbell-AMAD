//
//  DataLoader.swift
//  AMADLab2
//
//  Created by Alex Dugan on 2/1/22.
//

import Foundation

class DataLoader {
    var allData = [dataModel]()
    
    func loadData(filename: String){
        if let pathURL = Bundle.main.url(forResource: filename, withExtension: "plist"){
            let plistdecoder = PropertyListDecoder()
            do {
                let data = try Data(contentsOf: pathURL)
                
                allData = try plistdecoder.decode([dataModel].self, from: data)
            } catch {
                print("Somethings wrong with the data")
            }
        }
    }
    func getGenres() -> [String]{
        var genres = [String]()
        for genre in allData {
            genres.append(genre.genre)
        }
        return genres
    }
    func getStories(index:Int) -> [String]{
        return allData[index].stories
    }
}
