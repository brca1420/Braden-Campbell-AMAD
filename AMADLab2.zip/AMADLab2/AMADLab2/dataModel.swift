//
//  dataModel.swift
//  AMADLab2
//
//  Created by Alex Dugan on 2/1/22.
//

import Foundation

struct dataModel: Decodable {
    let genre : String
    let stories : [String]
}
