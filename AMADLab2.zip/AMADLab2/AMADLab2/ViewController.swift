//
//  ViewController.swift
//  AMADLab2
//
//  Created by Alex Dugan on 1/31/22.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var storyData = DataLoader()
    var genres = [String]()
    var stories = [String]()
    let genreComp = 0
    let storyComp = 1
    let filename = "stories"
    var genreRow = Int()
    var storyRow = Int()
    
    @IBOutlet weak var outputLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        storyData.loadData(filename: filename)
        genres = storyData.getGenres()
        stories = storyData.getStories(index: 0)
    }
    
    @IBOutlet weak var storyPicker: UIPickerView!
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == genreComp {
            return genres.count
        }
        else {
            return stories.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == genreComp {
            return genres[row]
        }
        else {
            return stories[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == genreComp {
            stories = storyData.getStories(index: row)
            
            storyPicker.reloadComponent(storyComp)
            
            storyPicker.selectRow(0, inComponent: storyComp, animated: true)
        }
        genreRow = pickerView.selectedRow(inComponent: genreComp)
        storyRow = pickerView.selectedRow(inComponent: storyComp)
        outputLabel.text = genres[genreRow] + stories[storyRow]
    }
    
}

