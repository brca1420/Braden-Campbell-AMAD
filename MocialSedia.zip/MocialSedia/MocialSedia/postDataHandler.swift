//
//  postDataHandler.swift
//  MocialSedia
//
//  Created by Alex Dugan on 2/28/22.
//

import Foundation

class PostDataHandler {
    var Allposts = [Post]()

   func loadjson() async {
       
       guard let urlPath = URL(string: "https://jsonplaceholder.typicode.com/posts")
       else {
           print("url error")
           return
       }
       do {
           let (data, responce) = try await URLSession.shared.data(from: urlPath, delegate: nil)
           guard (responce as? HTTPURLResponse)?.statusCode == 200
           else {
               print("file download error")
               return
           }
           print("download complete")
           parsejson(data)
       }
           catch {
               print(error.localizedDescription)
           }
       }
    
    func parsejson (_ data: Data) {
        do {
            let apiData = try! JSONDecoder().decode([Post].self, from: data)
            
            for post in apiData {
                Allposts.append(post)
                let body1 = post.body
                print(body1)
            }
            print(Allposts.count)
            print("parsejson done")
        }
            catch let jsonErr {
                print(jsonErr.localizedDescription)
                return
            }
        }
        
        
        func getPosts() -> [Post] {
            return Allposts
        }
    
    
}
 
