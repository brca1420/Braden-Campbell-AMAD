//
//  PostsData.swift
//  MocialSedia
//
//  Created by Alex Dugan on 2/28/22.
//

import Foundation

struct Post : Codable {
    let userID, id: Int
    let title : String
    let body : String
    
    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, title, body
    }
}

