//
//  PostVC.swift
//  MocialSedia
//
//  Created by Alex Dugan on 2/28/22.
//

import UIKit

class PostVC: UIViewController {
    var pBody = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var postBody: UILabel!
    override func viewWillAppear(_ animated: Bool) {
        postBody.text = pBody
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
