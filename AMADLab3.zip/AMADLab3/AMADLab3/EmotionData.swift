//
//  emotionData.swift
//  AMADLab3
//
//  Created by Alex Dugan on 2/9/22.
//

import Foundation

struct EmotionData : Codable {
    var emotion : String
    var things : [String]
}
