//
//  EmotionDataLoader.swift
//  AMADLab3
//
//  Created by Alex Dugan on 2/9/22.
//

import Foundation

class EmotionDataLoader {
    var allData = [EmotionData]()
    
    func loadData(filename: String){
        if let pathURL = Bundle.main.url(forResource: filename, withExtension: "plist"){
            let plistdecoder = PropertyListDecoder()
            do {
                let data = try Data(contentsOf: pathURL)
                allData = try plistdecoder.decode([EmotionData].self, from: data)
            }
            catch {
                print(error)
            }
        }
    }
    func getThings(index: Int) -> [String]{
        return allData[index].things
    }
    func getEmotions() -> [String]{
        var emotions = [String]()
        for item in allData{
            emotions.append(item.emotion)
        }
        return emotions
    }
    func addThing(index: Int, newThing:String, newIndex: Int){
        allData[index].things.insert(newThing, at: newIndex)
    }
    func deleteThing(index: Int, thingIndex: Int){
        allData[index].things.remove(at: thingIndex)
    }
}
