//
//  AddThingViewController.swift
//  AMADLab3
//
//  Created by Alex Dugan on 2/9/22.
//

import UIKit

class AddThingViewController: UIViewController {
    
    var addedThing = String()

    @IBOutlet weak var thingTextfield: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneSegue"{
            if thingTextfield.text?.isEmpty == false{
                addedThing = thingTextfield.text!
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
