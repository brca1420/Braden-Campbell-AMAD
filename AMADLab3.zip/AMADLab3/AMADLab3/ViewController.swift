//
//  ViewController.swift
//  AMADLab3
//
//  Created by Alex Dugan on 2/9/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

