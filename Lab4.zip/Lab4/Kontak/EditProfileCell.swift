//
//  EditProfileCell.swift
//  Kontak
//
//  Created by Alex Dugan on 2/17/22.
//

import UIKit

class EditProfileCell: UIViewController {
    var newContent = String()
    var entryIndex = Int()
    let titles = ["Full Name","Qualification","Phone Number","Email","Company"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        editTitle.text = titles[entryIndex]
    }
//    @IBAction func share3(_ sender: UIBarButtonItem) {
//        var imageArray = [UIImage]()
//        imageArray.append(image.image!)
//        let shareScreen = UIActivityViewController(activityItems: imageArray, applicationActivities: nil)
//        shareScreen.modalPresentationStyle = .popover
//        shareScreen.popoverPresentationController?.barButtonItem = sender
//        present(shareScreen, animated: true, completion: nil)
//    }
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var editTitle: UILabel!
    
    @IBAction func textField(_ sender: UITextField) {
    }
    @IBAction func doneButton(_ sender: UIButton) {
    }
    @IBOutlet weak var textFieldOutlet: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneEditSeg"{
            if textFieldOutlet.text?.isEmpty == false {
                newContent = textFieldOutlet.text!
                let profileVC = segue.destination as! ProfileVC
                profileVC.contents[entryIndex] = newContent
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
