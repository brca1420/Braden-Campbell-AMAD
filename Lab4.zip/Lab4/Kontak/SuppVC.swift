//
//  SuppVC.swift
//  Kontak
//
//  Created by Alex Dugan on 2/21/22.
//

import UIKit

class SuppVC: UICollectionReusableView {
    @IBOutlet weak var headerLabel: UILabel!
    
    @IBOutlet weak var footerLabel: UILabel!
}
